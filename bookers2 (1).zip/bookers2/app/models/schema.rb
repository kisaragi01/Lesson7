class Schema < ApplicationRecord
  belong_to :user
end
