# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '9645648684a4bd3be1068cc388a4dc53ca619790ad3b1d3c5c9869ed8b8c812f9a3429b7ff859518ba52938dff23f9343ed84101f1f1224721872d40439b815d'